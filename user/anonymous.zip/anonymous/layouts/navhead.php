<div data-role="header" style="padding: 20px;" data-position="fixed">
    <a href="#panel" class="ui-btn ui-btn-inline" data-icon="bars" style="margin-top: 7px">Hello</a>
    <div style="text-align: center;">JORDAN BANKING</div>
</div>