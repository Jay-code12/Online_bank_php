<div style="display: flex; justify-content: space-between;">
    <div><small>welcome!</small> <strong>Jaycode</strong></div>
    <div>logout</div>
</div>