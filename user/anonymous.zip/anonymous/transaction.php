<?php require_once("layouts/header.php"); ?>


        <br>
    </div>

    <br>

    <?php require_once("layouts/widget.php"); ?>

    <br>
    <table data-role="table" id="table-column-toggle" data-mode="" class="ui-responsive table-stroke">
        <div>
            <h4>Transactions</h4>
        </div>
        <thead>
            <tr>
                <th>Description</th>
                <th data-priority="1"><abbr title="Transactions">Amount</abbr></th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td><a href="#" data-rel="external">Citizen Kane</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Dr. Strangelove Or How I Learned to Stop Worrying and Love the
                        Bomb</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Citizen Kane</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Dr. Strangelove Or How I Learned to Stop Worrying and Love the
                        Bomb</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Citizen Kane</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Dr. Strangelove Or How I Learned to Stop Worrying and Love the
                        Bomb</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Citizen Kane</a>
                </td>
                <td>$1,000,000</td>
            </tr>
            <tr>
                <td><a href="#" data-rel="external">Dr. Strangelove Or How I Learned to Stop Worrying and Love the
                        Bomb</a>
                </td>
                <td>$1,000,000</td>
            </tr>
        </tbody>
    </table>
    <br>
    <div style="float: right;">
        <span>showing <small>6 of 64</small> <a href="#">Transactions</a></span>
    </div>
    <br>
    <br>

</div>
    
<?php require_once("layouts/footer.php"); ?>