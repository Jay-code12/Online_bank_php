<?php

class Database{

    // private $host = "localhost";
    // private $user = "root";
    // private $password = "";
    // private $db_name = "jordan"; 

    private $host = "localhost";
    private $user = "inte9828_cb_jordan";
    private $password = "cb_jordan";
    private $db_name = "inte9828_cb_jordan"; 
    

    public $pdo;
    
    protected function connect(){
        
        $conn = "mysql:host=$this->host; dbname=$this->db_name";
        $pdo = new PDO($conn, $this->user, $this->password);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        if($pdo == true){
            return $pdo;
        }else{
            return "Database not connected";
        }
    }


}
